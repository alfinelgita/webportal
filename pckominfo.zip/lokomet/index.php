<?php  
  // halaman utama (index.php) sengaja dikosongkan
  // karena langsung dialihkan ke file media.php
  // cara pengalihan file bisa dilihat melalui file .htaccess yang bisa dibuka pakai Notepad
?>
